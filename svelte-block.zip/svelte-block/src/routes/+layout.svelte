<script>
	import './app.css';
</script>

<div class="flex justify-center items-center h-screen">
	<slot />
</div>
