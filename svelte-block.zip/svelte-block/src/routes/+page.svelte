<script lang="ts">
	import Select from '$lib/dropdown/Select.svelte';

	let countries = [
		{ value: 'us', name: 'United States' },
		{ value: 'fr', name: 'France' },
		{ value: 'gb', name: 'United Kingdom' },
		{ value: 'de', name: 'Germany' },
		{ value: 'jp', name: 'Japan' },
		{ value: 'au', name: 'Australia' },
		{ value: 'cn', name: 'China' },
		{ value: 'in', name: 'India' },
		{ value: 'mx', name: 'Mexico' },
		{ value: 'br', name: 'Brazil' },
		{ value: 'ru', name: 'Russia' },
		{ value: 'it', name: 'Italy' },
		{ value: 'es', name: 'Spain' },
		{ value: 'id', name: 'Indonesia' },
		{ value: 'tr', name: 'Turkey' },
		{ value: 'kr', name: 'South Korea' },
		{ value: 'ca', name: 'Canada' },
		{ value: 'sa', name: 'Saudi Arabia' },
		{ value: 'ar', name: 'Argentina' },
		{ value: 'za', name: 'South Africa' },
		{ value: 'ir', name: 'Iran' },
		{ value: 'nl', name: 'Netherlands' },
		{ value: 'ch', name: 'Switzerland' },
		{ value: 'sg', name: 'Singapore' },
		{ value: 'eg', name: 'Egypt' },
		{ value: 'vn', name: 'Vietnam' },
		{ value: 'th', name: 'Thailand' },
		{ value: 'pl', name: 'Poland' },
		{ value: 'se', name: 'Sweden' }
	];

	let selected: any = undefined;
</script>

<div>
	<Select items={countries} bind:value={selected} />

	{#if selected}
		<div>Selected Value is {selected}</div>
	{/if}
</div>
