export interface PageSettingsProps {
	pageNumber: number;
}
