# GBS Svelte Component Library

Gbs svelte component library for internal distribution

# How to Run

```bash
    git clone ssh or whatever
    npm install
    npm run dev
```

## Testing With Playwright

This Project Uses Playwright to run test cases. Please install playwright with `npx playwright install` before runnig test command.